package com.example.springprojectshopproducts.controller;

import com.example.springprojectshopproducts.model.Product;
import com.example.springprojectshopproducts.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/products")
public class ProductController {

    @Autowired
    private ProductService productService;

    @GetMapping
    public String IndexPage(Model model){
        model.addAttribute("products", productService.findAll());
        return "products";
    }
    @GetMapping("/add")
    public String addProducts(Model model){
        model.addAttribute("addProducts", new Product());
        return "createProducts";
    }
    @PostMapping
    public String DodajProducts(Product product){
        productService.save(product);
        return "redirect:/products";
    }
    @GetMapping("/edit/{id}")
    public String UpdateProducts(@PathVariable("id") Integer id,Model model){
        model.addAttribute("product",productService.getId(id));
        return "EditProducts";
    }
    @PostMapping("/edit/{id}")
    public String EditProduct(@PathVariable int id, @ModelAttribute("product") Product product,Model model){
        Product result = productService.getId(id);
        result.setId(id);
        result.setNazwa(product.getNazwa());
        result.setDeadline(product.getDeadline());
        productService.save(result);
        return "redirect:/products";
    }
    @GetMapping("/{id}")
    public String DeleteByIdProduct(@PathVariable int id){
        productService.deleteById(id);
        return "redirect:/products";
    }

}
