INSERT INTO PRODUCTS(ID,NAZWA,DEADLINE)
VALUES (1,'Jablko', '2022-02-23'),
       (2,'Pomidor', '2022-02-16'),
       (3,'Banan', '2022-02-20')