drop table if exists products;
create table products(
                      id int primary key auto_increment,
                      nazwa varchar(20) not null,
                      deadline varchar(14) not null
)