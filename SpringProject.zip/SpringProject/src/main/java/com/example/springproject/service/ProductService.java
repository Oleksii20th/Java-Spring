package com.example.springproject.service;

import com.example.springproject.adapter.SqlProductRepository;
import com.example.springproject.model.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProductService {
    @Autowired
    private SqlProductRepository repository;
    public List<Product> findAll(){
        return repository.findAll();
    }
    public void save(Product product){
         repository.save(product);
    }
    public Product getId(Integer id){
        return repository.findById(id).get();
    }
    public void deleteById(Integer id){
         repository.deleteById(id);
    }
}
