package com.example.springschooltasksbabych.model.projection;

public class TaskWriteModel {
}
