package com.example.springschooltasksbabych.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice(annotations = IllegalExceptionProcessing.class)
public class ControllersExceptions {
    //private static final Logger logger = LoggerFactory.getLogger(ControllerAdvice.class);
    @ExceptionHandler(IllegalArgumentException.class)
    ResponseEntity<String> handlillegalArgument(IllegalArgumentException e){
        //logger.warn("NOT FOUND");
        return ResponseEntity.notFound().build();
    }
    @ExceptionHandler(IllegalStateException.class)
    ResponseEntity<String> handlillegalState(IllegalStateException e){
        return ResponseEntity.badRequest().body(e.getMessage());
    }
}
