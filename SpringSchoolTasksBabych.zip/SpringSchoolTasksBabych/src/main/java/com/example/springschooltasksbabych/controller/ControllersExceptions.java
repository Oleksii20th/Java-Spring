package com.example.springschooltasksbabych.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class ControllersExceptions {
    @ExceptionHandler(IllegalArgumentException.class)
    ResponseEntity<String> handlillegalArgument(IllegalArgumentException e){
        return ResponseEntity.notFound().build();
    }
    @ExceptionHandler(IllegalStateException.class)
    ResponseEntity<String> handlillegalState(IllegalStateException e){
        return ResponseEntity.badRequest().body(e.getMessage());
    }
}
